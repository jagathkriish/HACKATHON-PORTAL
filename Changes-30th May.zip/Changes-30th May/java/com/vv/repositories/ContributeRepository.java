package com.vv.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.transaction.annotation.Transactional;

import com.vv.model.Contributions;

public interface ContributeRepository extends PagingAndSortingRepository<Contributions, Long> {
	@Override
	List<Contributions> findAll();
	List<Contributions> findByideaId(Long idea_id);
	@Query("SELECT ctb from Contributions ctb where ctb.idea.id = ?1 and ctb.active= 'A'")
	List<Contributions> findByActiveIeaId(Long idea_id);
	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("update Contributions ctb set ctb.active = 'I' where ctb.idea.id = ?1")
	int inactivateContribution(Long idea_id);
	
}
