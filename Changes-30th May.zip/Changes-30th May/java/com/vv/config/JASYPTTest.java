/*package com.vv.config;

import org.jasypt.util.text.BasicTextEncryptor;

public class JASYPTTest {

	public static void main(String[] args) {
		BasicTextEncryptor textEncryptor = new BasicTextEncryptor();
		textEncryptor.setPassword("CAPG_ENC_SECRET777@*&@&/");
		String myEncryptedText = textEncryptor.encrypt("admin");
		String plainText = textEncryptor.decrypt(myEncryptedText);
		
		System.out.println(myEncryptedText +"   "+plainText);

	}

}*/